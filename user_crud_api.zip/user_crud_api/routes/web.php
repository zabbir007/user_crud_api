<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('user')->group(function () {

	Route::post('signup', 'UserController@signup')->name('signup');;    // sign up user
	Route::post('signin', 'UserController@signIn')->name('signIn');;   // Sign In user
    Route::post('delete-user/{id}', 'UserController@deleteUser')->name('deleteUser'); //delete user
    Route::get('show-all-user', 'UserController@showAllUser')->name('showAllUser');  // All user list


});

